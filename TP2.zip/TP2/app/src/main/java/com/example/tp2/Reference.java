package com.example.tp2;

import android.widget.TextView;

public class Reference {

    TextView calculView;
    TextView resultView;

    Reference(TextView calculView, TextView resultView){
        this.calculView = calculView;
        this.resultView = resultView;
    }

}
